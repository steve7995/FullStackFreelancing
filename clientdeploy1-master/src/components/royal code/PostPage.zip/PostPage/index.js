// import Navbar from "../Navbar/Navbar";
import Footer from "./footer/footer";
import Postform from "./Postform/Postform";

export default function PostPage() {

    return (
    
    <div style={{backgroundColor : "#F7ECDE",paddingTop : "100px"}}>
        {/* <Navbar /> */}
        <Postform />
        <Footer />
    </div>

    )
}